<template>
  <div class="sidebar-list-transaction">
    <img
      class="vector-11"
      src="https://anima-uploads.s3.amazonaws.com/projects/6346737d3c195ace20fe33e6/releases/6346744bfb6cd5506eea67db/img/vector-11@2x.svg"
      alt="Vector"
    />
    <div class="title-11 mulish-normal-white-16px">Drivers</div>
  </div>
</template>

<script>
export default {
  name: "SidebarListTransaction",
};
</script>

<style>
.sidebar-list-transaction,
.sidebar-list-transaction-1 {
  align-items: flex-start;
  border: 1px none;
  display: flex;
  gap: 17px;
  height: 56px;
  justify-content: flex-end;
  margin-right: 2px;
  min-width: 255px;
  padding: 16px 31px;
}

.vector-11,
.vector-12 {
  height: 18px;
  width: 16px;
}

.title-11,
.title-12 {
  letter-spacing: 0.2px;
  margin-top: 1px;
  min-height: 20px;
  width: 159px;
}
</style>
