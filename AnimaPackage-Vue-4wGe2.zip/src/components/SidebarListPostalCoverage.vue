<template>
  <div class="sidebar-list-postal-coverage">
    <img
      class="vector-9"
      src="https://anima-uploads.s3.amazonaws.com/projects/6346737d3c195ace20fe33e6/releases/6346744bfb6cd5506eea67db/img/vector-10@2x.svg"
      alt="Vector"
    />
    <div class="title-9 mulish-normal-white-16px">Admin Access</div>
  </div>
</template>

<script>
export default {
  name: "SidebarListPostalCoverage",
};
</script>

<style>
.sidebar-list-postal-coverage,
.sidebar-list-postal-coverage-1 {
  align-items: flex-start;
  border: 1px none;
  display: flex;
  gap: 16px;
  height: 56px;
  margin-right: 2px;
  min-width: 255px;
  padding: 17px 31px;
}

.vector-9,
.vector-10 {
  align-self: center;
  height: 14px;
  margin-top: 0.4px;
  width: 18px;
}

.title-9,
.title-10 {
  letter-spacing: 0.2px;
  min-height: 20px;
  width: 159px;
}
</style>
