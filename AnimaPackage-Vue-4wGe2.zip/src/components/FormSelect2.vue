<template>
  <div class="form-select-4"></div>
</template>

<script>
export default {
  name: "FormSelect2",
};
</script>

<style>
.form-select-4 {
  align-items: flex-start;
  border: 1px none;
  border-radius: 4px;
  box-shadow: 0px 2px 4px #a5a3ae4c;
  display: flex;
  left: 0;
  position: absolute;
  top: 1px;
  width: 200px;
}
</style>
