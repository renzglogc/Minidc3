<template>
  <div class="cards-default"></div>
</template>

<script>
export default {
  name: "CardsDefault",
};
</script>

<style>
.cards-default {
  background-color: var(--white);
  border: 1px solid;
  border-color: var(--snuff);
  border-radius: 8px;
  height: 582px;
  left: 55px;
  position: absolute;
  top: 73px;
  width: 380px;
}
</style>
