<template>
  <div class="footer">
    <img
      class="golog-logo-red-1"
      src="https://anima-uploads.s3.amazonaws.com/projects/6346737d3c195ace20fe33e6/releases/6346744bfb6cd5506eea67db/img/golog-logo-red-1@2x.png"
      alt="golog logo red 1"
    />
    <div class="overlap-group-3">
      <img
        class="seek-png-1"
        src="https://anima-uploads.s3.amazonaws.com/projects/6346737d3c195ace20fe33e6/releases/6346744bfb6cd5506eea67db/img/seekpng-1@2x.png"
        alt="SeekPng 1"
      />
      <p class="textfield-29 valign-text-middle mulish-bold-smoky-14px">
        ©2023 GOBUILDERS NETSOFT SDN BHD (1232479-T).ALL RIGHTS RESERVED.
      </p>
    </div>
  </div>
</template>

<script>
export default {
  name: "XFooter",
};
</script>

<style>
.footer,
.footer-1 {
  align-items: flex-start;
  display: flex;
  gap: 8px;
  height: 20px;
  left: 0;
  min-width: 1167px;
  position: absolute;
  top: 0;
}

.golog-logo-red-1,
.golog-logo-red-1-1 {
  height: 20px;
  object-fit: cover;
  width: 30px;
}

.overlap-group-3,
.overlap-group-4 {
  height: 19px;
  position: relative;
  width: 1127px;
}

.seek-png-1,
.seek-png-1-1 {
  height: 19px;
  left: 1052px;
  object-fit: cover;
  position: absolute;
  top: 0;
  width: 63px;
}

.textfield-29,
.textfield-30 {
  height: 17px;
  left: 0;
  letter-spacing: -0.3px;
  line-height: 13.5px;
  position: absolute;
  top: 1px;
  width: 1127px;
}
</style>
