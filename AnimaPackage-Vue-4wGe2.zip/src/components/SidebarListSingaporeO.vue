<template>
  <div class="sidebar-list-singapore-o">
    <img
      class="vector-4"
      src="https://anima-uploads.s3.amazonaws.com/projects/6346737d3c195ace20fe33e6/releases/6346744bfb6cd5506eea67db/img/vector-7@2x.svg"
      alt="Vector"
    />
    <div class="title-5 mulish-normal-white-16px">Price Checker</div>
  </div>
</template>

<script>
export default {
  name: "SidebarListSingaporeO",
};
</script>

<style>
.sidebar-list-singapore-o,
.sidebar-list-singapore-o-1 {
  align-items: flex-start;
  border: 1px none;
  display: flex;
  gap: 18px;
  height: 56px;
  margin-right: 2px;
  min-width: 255px;
  padding: 17px 31px;
}

.vector-4,
.vector-5 {
  height: 16px;
  margin-top: 1px;
  width: 16px;
}

.title-5,
.title-6 {
  letter-spacing: 0.2px;
  min-height: 20px;
  width: 159px;
}
</style>
